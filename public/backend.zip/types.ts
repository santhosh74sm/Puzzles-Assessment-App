export type UserRole = 'super_admin' | 'school_admin' | 'student';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  passwordHash: string;
  mustChangePassword: boolean;
  schoolId?: string;
  schoolName?: string;
  // Student attributes
  studentName?: string;
  className?: string;
  section?: string;
  schoolAdmissionNumber?: string;
  uniqueStudentId?: string; // App number
  createdAt: string;
  updatedAt: string;
}

export interface School {
  id: string;
  name: string;
  code: string;
  createdAt: string;
}

export type QuestionDifficulty = 'Easy' | 'Medium' | 'Hard';

export type QuestionType =
  | 'Math'
  | 'Puzzle'
  | 'Aptitude'
  | 'Simple Text'
  | 'Emoji'
  | 'Number'
  | 'Match'
  | 'Image';

export interface QuestionGroup {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
}

export interface MatchPair {
  left: string;
  right: string;
}

export interface Question {
  id: string;
  groupId: string;
  groupName: string;
  difficulty: QuestionDifficulty;
  questionType: QuestionType;
  content: string;
  timeSeconds: number;
  points: number;
  options?: string[];
  correctAnswer: any; // string, number, or record of match pairs
  metadata?: Record<string, any>;
  createdAt: string;
}

export type PublishMode = 'Selected Questions' | 'Random Questions';

export interface PublishTarget {
  schoolId: string;
  schoolName?: string;
  classes?: string[]; // Empty means all classes
  sections?: string[]; // Empty means all sections
  studentIds?: string[]; // Empty means all students in target
}

export interface PublishedTest {
  id: string;
  publishName: string;
  publishMode: PublishMode;
  target: PublishTarget;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  questionIds: string[]; // for Selected, or resolved pool
  randomCount?: number;
  shuffle: boolean;
  createdAt: string;
  createdBy: string;
}

export type TestAttemptStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'LOCKED_INCOMPLETE';

export interface QuestionAttemptLog {
  questionId: string;
  groupName: string;
  difficulty: QuestionDifficulty;
  questionType: QuestionType;
  content: string;
  points: number;
  studentAnswer: any;
  correctAnswer: any;
  isCorrect: boolean;
  timeAllowedSeconds: number;
  timeTakenSeconds: number;
  earnedPoints: number;
}

export interface StudentTestAssignment {
  id: string;
  publishedTestId: string;
  publishName: string;
  studentId: string;
  studentName: string;
  schoolId: string;
  schoolName: string;
  className: string;
  section: string;
  status: TestAttemptStatus;
  startedAt?: string;
  completedAt?: string;
  lockedAt?: string;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  totalPointsEarned: number;
  scoreOutOf100: number;
  totalTimeTakenSeconds: number;
  questions: QuestionAttemptLog[];
}

export interface PublishHistoryRecord {
  id: string;
  publishId: string;
  publishName: string;
  date: string;
  time: string;
  schoolId: string;
  schoolName: string;
  classes: string[];
  sections: string[];
  totalRecipients: number;
  publishMode: PublishMode;
  assignedQuestionsCount: number;
  completedCount: number;
  incompleteCount: number;
  studentsStatus: {
    studentId: string;
    studentName: string;
    className: string;
    section: string;
    status: TestAttemptStatus;
    completionDate?: string;
    completionTime?: string;
    scoreOutOf100?: number;
  }[];
}
