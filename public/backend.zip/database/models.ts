import mongoose, { Schema, Document } from 'mongoose';

// User Document
export interface IUserDocument extends Document {
  id?: string;
  username: string;
  role: 'super_admin' | 'school_admin' | 'student';
  passwordHash: string;
  mustChangePassword: boolean;
  schoolId?: string;
  schoolName?: string;
  studentName?: string;
  className?: string;
  section?: string;
  schoolAdmissionNumber?: string;
  uniqueStudentId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export const UserSchema = new Schema<IUserDocument>(
  {
    username: { type: String, required: true, unique: true, index: true },
    role: { type: String, required: true, enum: ['super_admin', 'school_admin', 'student'] },
    passwordHash: { type: String, required: true },
    mustChangePassword: { type: Boolean, default: true },
    schoolId: { type: String, index: true },
    schoolName: { type: String },
    studentName: { type: String },
    className: { type: String, index: true },
    section: { type: String, index: true },
    schoolAdmissionNumber: { type: String },
    uniqueStudentId: { type: String, index: true },
  },
  { timestamps: true }
);

// School Document
export interface ISchoolDocument extends Document {
  id?: string;
  name: string;
  code: string;
  createdAt: Date;
}

export const SchoolSchema = new Schema<ISchoolDocument>(
  {
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true, uppercase: true },
  },
  { timestamps: true }
);

// Question Group Document
export interface IQuestionGroupDocument extends Document {
  id?: string;
  name: string;
  description?: string;
  createdAt: Date;
}

export const QuestionGroupSchema = new Schema<IQuestionGroupDocument>(
  {
    name: { type: String, required: true, unique: true },
    description: { type: String, default: '' },
  },
  { timestamps: true }
);

// Question Document
export interface IQuestionDocument extends Document {
  id?: string;
  groupId: string;
  groupName: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  questionType: string;
  content: string;
  timeSeconds: number;
  points: number;
  options: string[];
  correctAnswer: any;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export const QuestionSchema = new Schema<IQuestionDocument>(
  {
    groupId: { type: String, required: true, index: true },
    groupName: { type: String, required: true },
    difficulty: { type: String, required: true, enum: ['Easy', 'Medium', 'Hard'], index: true },
    questionType: { type: String, required: true },
    content: { type: String, required: true },
    timeSeconds: { type: Number, required: true, min: 5 },
    points: { type: Number, required: true, min: 1 },
    options: { type: [String], default: [] },
    correctAnswer: { type: Schema.Types.Mixed, required: true },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true }
);

// Published Test Document
export interface IPublishedTestDocument extends Document {
  id?: string;
  publishName: string;
  publishMode: 'Selected Questions' | 'Random Questions';
  schoolId: string;
  classes: string[];
  sections: string[];
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  shuffle: boolean;
  selectedQuestionIds: string[];
  randomCount?: number;
  createdAt: Date;
}

export const PublishedTestSchema = new Schema<IPublishedTestDocument>(
  {
    publishName: { type: String, required: true },
    publishMode: { type: String, required: true, enum: ['Selected Questions', 'Random Questions'] },
    schoolId: { type: String, required: true, index: true },
    classes: { type: [String], default: [] },
    sections: { type: [String], default: [] },
    startDate: { type: String, required: true },
    startTime: { type: String, required: true },
    endDate: { type: String, required: true },
    endTime: { type: String, required: true },
    shuffle: { type: Boolean, default: false },
    selectedQuestionIds: { type: [String], default: [] },
    randomCount: { type: Number, default: 5 },
  },
  { timestamps: true }
);

// Student Test Assignment Document
export interface IStudentTestAssignmentDocument extends Document {
  id?: string;
  publishedTestId: string;
  publishName: string;
  studentId: string;
  schoolId: string;
  className: string;
  section: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'LOCKED_INCOMPLETE';
  scoreOutOf100: number;
  totalPointsEarned: number;
  totalPossiblePoints: number;
  questions: any[];
  studentAnswers: any[];
  startedAt?: Date;
  completedAt?: Date;
}

export const StudentTestAssignmentSchema = new Schema<IStudentTestAssignmentDocument>(
  {
    publishedTestId: { type: String, required: true, index: true },
    publishName: { type: String, required: true },
    studentId: { type: String, required: true, index: true },
    schoolId: { type: String, required: true, index: true },
    className: { type: String, required: true },
    section: { type: String, required: true },
    status: {
      type: String,
      required: true,
      enum: ['NOT_STARTED', 'IN_PROGRESS', 'COMPLETED', 'LOCKED_INCOMPLETE'],
      default: 'NOT_STARTED',
      index: true,
    },
    scoreOutOf100: { type: Number, default: 0 },
    totalPointsEarned: { type: Number, default: 0 },
    totalPossiblePoints: { type: Number, default: 0 },
    questions: { type: [Schema.Types.Mixed], default: [] },
    studentAnswers: { type: [Schema.Types.Mixed], default: [] },
    startedAt: { type: Date },
    completedAt: { type: Date },
  },
  { timestamps: true }
);

// Publish History Document
export interface IPublishHistoryDocument extends Document {
  id?: string;
  publishId: string;
  publishName: string;
  date: string;
  time: string;
  schoolId: string;
  schoolName: string;
  classes: string[];
  sections: string[];
  totalRecipients: number;
  publishMode: 'Selected Questions' | 'Random Questions';
  assignedQuestionsCount: number;
  completedCount: number;
  incompleteCount: number;
  studentsStatus: any[];
}

export const PublishHistorySchema = new Schema<IPublishHistoryDocument>(
  {
    publishId: { type: String, required: true, unique: true, index: true },
    publishName: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    schoolId: { type: String, required: true, index: true },
    schoolName: { type: String, required: true },
    classes: { type: [String], default: [] },
    sections: { type: [String], default: [] },
    totalRecipients: { type: Number, default: 0 },
    publishMode: { type: String, required: true },
    assignedQuestionsCount: { type: Number, default: 0 },
    completedCount: { type: Number, default: 0 },
    incompleteCount: { type: Number, default: 0 },
    studentsStatus: { type: [Schema.Types.Mixed], default: [] },
  },
  { timestamps: true }
);

export const UserModel = mongoose.models.User || mongoose.model<IUserDocument>('User', UserSchema);
export const SchoolModel = mongoose.models.School || mongoose.model<ISchoolDocument>('School', SchoolSchema);
export const QuestionGroupModel = mongoose.models.QuestionGroup || mongoose.model<IQuestionGroupDocument>('QuestionGroup', QuestionGroupSchema);
export const QuestionModel = mongoose.models.Question || mongoose.model<IQuestionDocument>('Question', QuestionSchema);
export const PublishedTestModel = mongoose.models.PublishedTest || mongoose.model<IPublishedTestDocument>('PublishedTest', PublishedTestSchema);
export const StudentTestAssignmentModel = mongoose.models.StudentTestAssignment || mongoose.model<IStudentTestAssignmentDocument>('StudentTestAssignment', StudentTestAssignmentSchema);
export const PublishHistoryModel = mongoose.models.PublishHistory || mongoose.model<IPublishHistoryDocument>('PublishHistory', PublishHistorySchema);
