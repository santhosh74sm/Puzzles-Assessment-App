import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const TARGET_URI = (process.env.MONGO_URI || process.env.MONGODB_URI || '').trim();

async function seed() {
  if (!TARGET_URI) {
    throw new Error('Neither MONGO_URI nor MONGODB_URI is set. Please configure your MongoDB Atlas URI in .env');
  }
  const maskedUri = TARGET_URI.replace(/:([^@/]+)@/, ':****@');
  console.log(`Connecting to MongoDB at: ${maskedUri}...`);
  await mongoose.connect(TARGET_URI, { autoIndex: true });
  console.log(`Connected! Target database: ${mongoose.connection.name}...`);

  const db = mongoose.connection.db;

  // 1. Users
  const userColl = db.collection('users');
  const salt = bcrypt.genSaltSync(10);
  await userColl.deleteMany({});
  await userColl.insertMany([
    {
      username: 'Rolecall',
      role: 'super_admin',
      passwordHash: bcrypt.hashSync('Roll_Call', salt),
      mustChangePassword: true,
      createdAt: new Date(),
    },
    {
      username: 'ADM-GWH-789',
      role: 'school_admin',
      passwordHash: bcrypt.hashSync('ADM-GWH-789', salt),
      mustChangePassword: true,
      schoolName: 'Greenwood High International School',
      createdAt: new Date(),
    },
    {
      username: 'STU-701-ALEX',
      role: 'student',
      studentName: 'Alex Rivera',
      className: 'Class 7',
      section: 'A',
      schoolAdmissionNumber: 'ADM-2026-701',
      uniqueStudentId: 'STU-701-ALEX',
      passwordHash: bcrypt.hashSync('STU-701-ALEX', salt),
      mustChangePassword: true,
      createdAt: new Date(),
    },
    {
      username: 'STU-702-PRIYA',
      role: 'student',
      studentName: 'Priya Sharma',
      className: 'Class 7',
      section: 'B',
      schoolAdmissionNumber: 'ADM-2026-702',
      uniqueStudentId: 'STU-702-PRIYA',
      passwordHash: bcrypt.hashSync('STU-702-PRIYA', salt),
      mustChangePassword: true,
      createdAt: new Date(),
    },
  ]);
  console.log('✓ Seeded users collection (4 documents)');

  // 2. Schools
  const schoolColl = db.collection('schools');
  await schoolColl.deleteMany({});
  await schoolColl.insertMany([
    {
      name: 'Greenwood High International School',
      code: 'GWH-001',
      createdAt: new Date(),
    },
    {
      name: 'Oakridge World Academy',
      code: 'OWA-002',
      createdAt: new Date(),
    },
  ]);
  console.log('✓ Seeded schools collection (2 documents)');

  // 3. Question Groups
  const groupColl = db.collection('questiongroups');
  await groupColl.deleteMany({});
  await groupColl.insertMany([
    { name: 'Aptitude', description: 'Mathematical, logical reasoning & analytical aptitude', createdAt: new Date() },
    { name: 'Reasoning', description: 'Pattern matching, emoji deciphering & deduction', createdAt: new Date() },
    { name: 'Creativity', description: 'Spatial reasoning, match combinations & divergent problem solving', createdAt: new Date() },
    { name: 'Thinking', description: 'Critical thinking, algebraic logic & multi-step word puzzles', createdAt: new Date() },
  ]);
  console.log('✓ Seeded questiongroups collection (4 documents)');

  // 4. Questions
  const qColl = db.collection('questions');
  await qColl.deleteMany({});
  await qColl.insertMany([
    {
      groupName: 'Aptitude',
      difficulty: 'Easy',
      questionType: 'Math',
      content: 'What is the missing number in the sequence? 3, 6, 12, 24, ___?',
      timeSeconds: 30,
      points: 10,
      options: ['36', '48', '42', '50'],
      correctAnswer: '48',
      createdAt: new Date(),
    },
    {
      groupName: 'Reasoning',
      difficulty: 'Easy',
      questionType: 'Emoji',
      content: 'Decode the hidden word puzzle from emojis: ☀️ + 👓 = ?',
      timeSeconds: 30,
      points: 10,
      options: ['Sunglasses', 'Sunlight', 'Hot Day', 'Beach'],
      correctAnswer: 'Sunglasses',
      createdAt: new Date(),
    },
    {
      groupName: 'Creativity',
      difficulty: 'Medium',
      questionType: 'Match',
      content: 'Match each shape with its internal angle sum:',
      timeSeconds: 45,
      points: 15,
      options: [],
      correctAnswer: { Triangle: '180°', Quadrilateral: '360°', Pentagon: '540°' },
      createdAt: new Date(),
    },
    {
      groupName: 'Thinking',
      difficulty: 'Medium',
      questionType: 'Puzzle',
      content: 'A father is 4 times older than his daughter. In 20 years, he will be twice as old as her. How old is the daughter today?',
      timeSeconds: 60,
      points: 20,
      options: ['10', '15', '20', '25'],
      correctAnswer: '10',
      createdAt: new Date(),
    },
    {
      groupName: 'Reasoning',
      difficulty: 'Hard',
      questionType: 'Number',
      content: 'Fill the 3x3 magic grid center: If rows, columns, and diagonals all sum to 15 using distinct digits 1 to 9, which number must occupy the central cell?',
      timeSeconds: 60,
      points: 25,
      options: ['3', '5', '7', '9'],
      correctAnswer: '5',
      createdAt: new Date(),
    },
  ]);
  console.log('✓ Seeded questions collection (5 documents)');

  // 5. Ensure other required collections are created
  const otherCollections = ['publishedtests', 'studenttestassignments', 'publishhistories'];
  for (const collName of otherCollections) {
    try {
      await db.createCollection(collName);
    } catch (e) {}
  }
  console.log('✓ Verified publishedtests, studenttestassignments, publishhistories collections');

  console.log('\n======================================================');
  console.log('SUCCESS! Database "puzzles_assessment_dev" has been initialized and populated.');
  console.log('Open MongoDB Compass or Atlas to inspect the "puzzles_assessment_dev" database.');
  console.log('======================================================');

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
