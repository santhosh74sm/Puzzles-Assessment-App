import { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  Layers,
  Send,
  History,
  FileBarChart,
  UserPlus,
  PlusCircle,
  Eye,
  CheckCircle,
  XCircle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Shuffle,
  Play,
  Clock,
  Sparkles,
  ChevronRight,
  Filter,
  Search,
} from 'lucide-react';
import { FlameMiniGameCanvas } from './FlameMiniGameCanvas.tsx';

interface SuperAdminDashboardProps {
  token: string;
}

export function SuperAdminDashboard({ token }: SuperAdminDashboardProps) {
  const [tab, setTab] = useState<
    'schools' | 'question_bank' | 'publish' | 'history' | 'reports' | 'preview_test'
  >('schools');

  const [schools, setSchools] = useState<any[]>([]);
  const [questionGroups, setQuestionGroups] = useState<any[]>([]);
  const [allQuestions, setAllQuestions] = useState<any[]>([]);
  const [historyList, setHistoryList] = useState<any[]>([]);
  const [selectedHistoryDetail, setSelectedHistoryDetail] = useState<any | null>(null);

  // Modal / form states
  const [newSchoolName, setNewSchoolName] = useState('');
  const [newSchoolCode, setNewSchoolCode] = useState('');
  const [createdAdminResult, setCreatedAdminResult] = useState<any | null>(null);

  // New Student form
  const [studentForm, setStudentForm] = useState({
    schoolId: '',
    studentName: '',
    className: 'Class 7',
    section: 'A',
    schoolAdmissionNumber: '',
  });
  const [createdStudentResult, setCreatedStudentResult] = useState<any | null>(null);

  // New Question Group
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');

  // Group View Modal (Read Only)
  const [viewGroupModal, setViewGroupModal] = useState<any | null>(null);

  // New Question form
  const [questionForm, setQuestionForm] = useState({
    groupId: '',
    difficulty: 'Easy',
    questionType: 'Math',
    content: '',
    timeSeconds: 30,
    points: 10,
    options: '10, 20, 30, 40',
    correctAnswer: '20',
  });

  // Publish Form State
  const [publishName, setPublishName] = useState('');
  const [publishMode, setPublishMode] = useState<'Selected Questions' | 'Random Questions'>('Selected Questions');
  const [selectedSchoolId, setSelectedSchoolId] = useState('');
  const [selectedClasses, setSelectedClasses] = useState<string[]>([]);
  const [selectedSections, setSelectedSections] = useState<string[]>([]);
  const [selectedQuestionsForPublish, setSelectedQuestionsForPublish] = useState<string[]>([]);
  const [shuffleQuestions, setShuffleQuestions] = useState(false);
  const [randomCount, setRandomCount] = useState(5);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('09:00');
  const [endDate, setEndDate] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [endTime, setEndTime] = useState('18:00');
  const [publishFeedback, setPublishFeedback] = useState<string | null>(null);

  // Preview Test State (for Selected Questions)
  const [previewActiveIndex, setPreviewActiveIndex] = useState(0);

  // Reports state
  const [reportSchoolId, setReportSchoolId] = useState('');
  const [reportStudents, setReportStudents] = useState<any[]>([]);
  const [selectedStudentReport, setSelectedStudentReport] = useState<any | null>(null);
  const [reportSearch, setReportSearch] = useState('');

  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };

  const loadData = async () => {
    try {
      const [resSch, resGrp, resQ, resHist] = await Promise.all([
        fetch('/api/schools', { headers }),
        fetch('/api/question-groups', { headers }),
        fetch('/api/questions', { headers }),
        fetch('/api/publish-history', { headers }),
      ]);
      const dataSch = await resSch.json();
      const dataGrp = await resGrp.json();
      const dataQ = await resQ.json();
      const dataHist = await resHist.json();

      setSchools(Array.isArray(dataSch) ? dataSch : []);
      setQuestionGroups(Array.isArray(dataGrp) ? dataGrp : []);
      setAllQuestions(Array.isArray(dataQ) ? dataQ : []);
      setHistoryList(Array.isArray(dataHist) ? dataHist : []);

      if (dataSch.length > 0 && !selectedSchoolId) {
        setSelectedSchoolId(dataSch[0].id);
        setReportSchoolId(dataSch[0].id);
        setStudentForm((prev) => ({ ...prev, schoolId: dataSch[0].id }));
      }
      if (dataGrp.length > 0 && !questionForm.groupId) {
        setQuestionForm((prev) => ({ ...prev, groupId: dataGrp[0].id }));
      }
    } catch (e) {
      console.error('Failed to load super admin data', e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSchoolName || !newSchoolCode) return;
    try {
      const res = await fetch('/api/schools', {
        method: 'POST',
        headers,
        body: JSON.stringify({ name: newSchoolName, code: newSchoolCode }),
      });
      if (res.ok) {
        setNewSchoolName('');
        setNewSchoolCode('');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateSchoolAdmin = async (schoolId: string) => {
    try {
      const res = await fetch(`/api/schools/${schoolId}/admins`, {
        method: 'POST',
        headers,
      });
      const data = await res.json();
      if (res.ok) {
        setCreatedAdminResult(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers,
        body: JSON.stringify(studentForm),
      });
      const data = await res.json();
      if (res.ok) {
        setCreatedStudentResult(data);
        setStudentForm((prev) => ({
          ...prev,
          studentName: '',
          schoolAdmissionNumber: '',
        }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName) return;
    try {
      const res = await fetch('/api/question-groups', {
        method: 'POST',
        headers,
        body: JSON.stringify({ name: newGroupName, description: newGroupDesc }),
      });
      if (res.ok) {
        setNewGroupName('');
        setNewGroupDesc('');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    const opts = questionForm.options.split(',').map((s) => s.trim()).filter(Boolean);
    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ...questionForm,
          options: opts,
        }),
      });
      if (res.ok) {
        setQuestionForm((prev) => ({
          ...prev,
          content: '',
          correctAnswer: '',
        }));
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    setPublishFeedback(null);
    if (!publishName.trim()) {
      setPublishFeedback('Please specify a Publish Name (e.g. Class 7 Reasoning Test - September)');
      return;
    }
    if (publishMode === 'Selected Questions' && selectedQuestionsForPublish.length === 0) {
      setPublishFeedback('Please select at least 1 question from Question Bank.');
      return;
    }

    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          publishName,
          publishMode,
          target: {
            schoolId: selectedSchoolId,
            classes: selectedClasses,
            sections: selectedSections,
          },
          startDate,
          startTime,
          endDate,
          endTime,
          selectedQuestionIds: selectedQuestionsForPublish,
          randomCount: Number(randomCount),
          shuffle: shuffleQuestions,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setPublishFeedback(`Successfully published to ${data.assignedStudentCount} students!`);
        setPublishName('');
        setSelectedQuestionsForPublish([]);
        loadData();
      } else {
        setPublishFeedback(data.error || 'Failed to publish test');
      }
    } catch (err: any) {
      setPublishFeedback(err.message);
    }
  };

  const fetchReportsForSchool = async (schId: string) => {
    try {
      const res = await fetch(`/api/reports/schools/${schId}/students?search=${reportSearch}`, { headers });
      const data = await res.json();
      setReportStudents(Array.isArray(data) ? data : []);
      setSelectedStudentReport(null);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (reportSchoolId) {
      fetchReportsForSchool(reportSchoolId);
    }
  }, [reportSchoolId, reportSearch]);

  const viewStudentReportDetail = async (studentId: string) => {
    try {
      const res = await fetch(`/api/reports/students/${studentId}`, { headers });
      const data = await res.json();
      setSelectedStudentReport(data);
    } catch (e) {
      console.error(e);
    }
  };

  const viewHistoryDetail = async (publishId: string) => {
    try {
      const res = await fetch(`/api/publish-history/${publishId}`, { headers });
      const data = await res.json();
      setSelectedHistoryDetail(data);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 border-r border-slate-800 p-4 shrink-0 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 px-3 py-4 border-b border-slate-800 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-base leading-tight">Super Admin</h1>
              <p className="text-xs text-indigo-400 font-mono">Workspace Director</p>
            </div>
          </div>

          <nav className="space-y-1">
            <button
              onClick={() => setTab('schools')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === 'schools'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Schools & Students</span>
            </button>

            <button
              onClick={() => setTab('question_bank')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === 'question_bank'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Question Bank & Groups</span>
            </button>

            <button
              onClick={() => setTab('publish')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === 'publish'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>Publish Assessment</span>
            </button>

            <button
              onClick={() => setTab('history')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === 'history'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Publish History</span>
            </button>

            <button
              onClick={() => setTab('reports')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === 'reports'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FileBarChart className="w-4 h-4" />
              <span>Student Reports & Timeline</span>
            </button>
          </nav>
        </div>

        <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-500 space-y-1">
          <p>Role: Super Admin</p>
          <div className="flex items-center gap-1.5 text-emerald-400 font-mono text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>MongoDB: Atlas Cluster</span>
          </div>
          <p className="text-[10px] text-slate-400 font-mono">DB: puzzles_assessment_dev</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto">
        {/* ============================================================ */}
        {/* TAB 1: SCHOOLS & STUDENTS */}
        {/* ============================================================ */}
        {tab === 'schools' && (
          <div className="space-y-8 max-w-6xl">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">School Workspaces & Roster</h2>
              <p className="text-sm text-slate-400">
                Create isolated school workspaces, generate School Admins, and register students.
              </p>
            </div>

            {/* Notification of Created Admin or Student Credentials */}
            {createdAdminResult && (
              <div className="p-4 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 text-sm flex items-start justify-between">
                <div>
                  <h4 className="font-bold text-indigo-300">New School Admin Created Successfully:</h4>
                  <p className="mt-1 font-mono text-slate-200">
                    Username / Unique Admin ID: <strong>{createdAdminResult.username}</strong>
                  </p>
                  <p className="font-mono text-slate-200">
                    Initial Password: <strong>{createdAdminResult.initialPassword}</strong>
                  </p>
                  <p className="text-xs text-amber-400 mt-1">* Mandatory first login password change enforced.</p>
                </div>
                <button
                  onClick={() => setCreatedAdminResult(null)}
                  className="text-slate-400 hover:text-white"
                >
                  &times;
                </button>
              </div>
            )}

            {createdStudentResult && (
              <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-sm flex items-start justify-between">
                <div>
                  <h4 className="font-bold text-emerald-300">Student Registered Successfully:</h4>
                  <p className="mt-1 font-mono text-slate-200">
                    Student Name: {createdStudentResult.student.studentName} ({createdStudentResult.student.className} - {createdStudentResult.student.section})
                  </p>
                  <p className="font-mono text-slate-200">
                    Username / Student ID: <strong>{createdStudentResult.credentials.username}</strong>
                  </p>
                  <p className="font-mono text-slate-200">
                    Initial Password: <strong>{createdStudentResult.credentials.initialPassword}</strong>
                  </p>
                  <p className="text-xs text-amber-400 mt-1">* Mandatory first login password change enforced.</p>
                </div>
                <button
                  onClick={() => setCreatedStudentResult(null)}
                  className="text-slate-400 hover:text-white"
                >
                  &times;
                </button>
              </div>
            )}

            {/* School Workspace Creation & List */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-indigo-400" />
                  Add New School
                </h3>
                <form onSubmit={handleCreateSchool} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      School Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Greenwood International"
                      value={newSchoolName}
                      onChange={(e) => setNewSchoolName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      School Code
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. GWH"
                      value={newSchoolCode}
                      onChange={(e) => setNewSchoolCode(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all"
                  >
                    Create School
                  </button>
                </form>
              </div>

              {/* School Cards */}
              <div className="lg:col-span-2 space-y-4">
                <h3 className="font-bold text-lg">Active School Workspaces ({schools.length})</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {schools.map((sch) => (
                    <div
                      key={sch.id}
                      className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs px-2.5 py-1 rounded-md bg-indigo-950 text-indigo-400 border border-indigo-800/60 font-mono">
                            {sch.code}
                          </span>
                          <span className="text-xs text-slate-500">Workspace</span>
                        </div>
                        <h4 className="font-bold text-base mt-2 text-white">{sch.name}</h4>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => handleCreateSchoolAdmin(sch.id)}
                          className="text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 font-medium transition-all"
                        >
                          + Create Admin ID
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Student Registration Form */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-indigo-400" />
                Register New Student (School Roster)
              </h3>
              <form onSubmit={handleCreateStudent} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Select School
                  </label>
                  <select
                    value={studentForm.schoolId}
                    onChange={(e) => setStudentForm({ ...studentForm, schoolId: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    {schools.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Student Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sophia Martinez"
                    value={studentForm.studentName}
                    onChange={(e) => setStudentForm({ ...studentForm, studentName: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Admission Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ADM-2026-99"
                    value={studentForm.schoolAdmissionNumber}
                    onChange={(e) =>
                      setStudentForm({ ...studentForm, schoolAdmissionNumber: e.target.value })
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Class
                  </label>
                  <select
                    value={studentForm.className}
                    onChange={(e) => setStudentForm({ ...studentForm, className: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="Class 6">Class 6</option>
                    <option value="Class 7">Class 7</option>
                    <option value="Class 8">Class 8</option>
                    <option value="Class 9">Class 9</option>
                    <option value="Class 10">Class 10</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Section
                  </label>
                  <select
                    value={studentForm.section}
                    onChange={(e) => setStudentForm({ ...studentForm, section: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="A">Section A</option>
                    <option value="B">Section B</option>
                    <option value="C">Section C</option>
                  </select>
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all"
                  >
                    + Register Student
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 2: QUESTION BANK & GROUPS */}
        {/* ============================================================ */}
        {tab === 'question_bank' && (
          <div className="space-y-8 max-w-6xl">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Question Groups & Question Bank</h2>
              <p className="text-sm text-slate-400">
                Create unlimited groups (e.g. Creativity, Thinking, Reasoning, Aptitude), each with Easy, Medium, Hard tiers.
              </p>
            </div>

            {/* Create Group & Create Question row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Create Group */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-indigo-400" />
                  Add Question Group
                </h3>
                <form onSubmit={handleCreateGroup} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Group Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Aptitude, Creativity, Thinking"
                      value={newGroupName}
                      onChange={(e) => setNewGroupName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Description
                    </label>
                    <textarea
                      placeholder="Brief domain explanation"
                      value={newGroupDesc}
                      onChange={(e) => setNewGroupDesc(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all"
                  >
                    Create Group
                  </button>
                </form>
              </div>

              {/* Create Question */}
              <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-indigo-400" />
                  Add Question to Group & Difficulty
                </h3>
                <form onSubmit={handleCreateQuestion} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Group
                    </label>
                    <select
                      value={questionForm.groupId}
                      onChange={(e) => setQuestionForm({ ...questionForm, groupId: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      {questionGroups.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Difficulty Level
                    </label>
                    <select
                      value={questionForm.difficulty}
                      onChange={(e) => setQuestionForm({ ...questionForm, difficulty: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      <option value="Easy">Easy</option>
                      <option value="Medium">Medium</option>
                      <option value="Hard">Hard (Final Level)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Question Type
                    </label>
                    <select
                      value={questionForm.questionType}
                      onChange={(e) => setQuestionForm({ ...questionForm, questionType: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      <option value="Math">Math</option>
                      <option value="Puzzle">Puzzle</option>
                      <option value="Aptitude">Aptitude</option>
                      <option value="Simple Text">Simple Text</option>
                      <option value="Emoji">Emoji</option>
                      <option value="Number">Number</option>
                      <option value="Match">Match</option>
                    </select>
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Question Content / Prompt
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Decode the hidden word puzzle from emojis: ☀️ + 👓 = ?"
                      value={questionForm.content}
                      onChange={(e) => setQuestionForm({ ...questionForm, content: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Time Allowed (Seconds)
                    </label>
                    <input
                      type="number"
                      required
                      min={10}
                      max={300}
                      value={questionForm.timeSeconds}
                      onChange={(e) => setQuestionForm({ ...questionForm, timeSeconds: Number(e.target.value) })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Points
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={100}
                      value={questionForm.points}
                      onChange={(e) => setQuestionForm({ ...questionForm, points: Number(e.target.value) })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Correct Answer
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sunglasses"
                      value={questionForm.correctAnswer}
                      onChange={(e) => setQuestionForm({ ...questionForm, correctAnswer: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Options (Comma-separated)
                    </label>
                    <input
                      type="text"
                      placeholder="Sunglasses, Sunlight, Hot Day, Beach"
                      value={questionForm.options}
                      onChange={(e) => setQuestionForm({ ...questionForm, options: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>

                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all"
                    >
                      + Save to Question Bank
                    </button>
                  </div>
                </form>
              </div>
            </div>

            {/* Group View Option (Read-Only: Easy, Medium, Hard breakdown) */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">Question Groups Breakdown (View Mode)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {questionGroups.map((grp) => (
                  <div
                    key={grp.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white">{grp.name}</span>
                        <button
                          onClick={() => setViewGroupModal(grp)}
                          className="text-xs px-2.5 py-1 rounded-lg bg-indigo-950 text-indigo-400 border border-indigo-800/80 hover:bg-indigo-900 flex items-center gap-1 transition-all"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View Mode
                        </button>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-1">{grp.description || 'No description'}</p>

                      <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                        <div className="p-2 rounded-xl bg-slate-800/70 border border-slate-700/60">
                          <span className="text-xs text-emerald-400 block font-semibold">Easy</span>
                          <span className="text-base font-bold text-white">{grp.breakdown?.Easy?.count || 0}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-800/70 border border-slate-700/60">
                          <span className="text-xs text-amber-400 block font-semibold">Medium</span>
                          <span className="text-base font-bold text-white">{grp.breakdown?.Medium?.count || 0}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-800/70 border border-slate-700/60">
                          <span className="text-xs text-rose-400 block font-semibold">Hard</span>
                          <span className="text-base font-bold text-white">{grp.breakdown?.Hard?.count || 0}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Read-Only View Modal */}
            {viewGroupModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
                <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                    <div>
                      <span className="text-xs font-mono uppercase text-indigo-400">Read-Only View</span>
                      <h3 className="text-xl font-bold text-white">{viewGroupModal.name} Group</h3>
                    </div>
                    <button
                      onClick={() => setViewGroupModal(null)}
                      className="text-slate-400 hover:text-white text-lg font-bold"
                    >
                      &times;
                    </button>
                  </div>

                  <div className="space-y-6">
                    {(['Easy', 'Medium', 'Hard'] as const).map((diff) => {
                      const tier = viewGroupModal.breakdown?.[diff];
                      return (
                        <div key={diff} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h4
                              className={`text-sm font-bold uppercase tracking-wider ${
                                diff === 'Easy'
                                  ? 'text-emerald-400'
                                  : diff === 'Medium'
                                  ? 'text-amber-400'
                                  : 'text-rose-400'
                              }`}
                            >
                              {diff} Tier ({tier?.count || 0} questions)
                            </h4>
                          </div>

                          {tier?.questions && tier.questions.length > 0 ? (
                            <div className="space-y-2">
                              {tier.questions.map((q: any) => (
                                <div
                                  key={q.id}
                                  className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between text-sm"
                                >
                                  <div>
                                    <p className="text-white font-medium">{q.content}</p>
                                    <span className="text-xs text-indigo-400">Type: {q.questionType}</span>
                                  </div>
                                  <div className="flex items-center gap-3 shrink-0 font-mono text-xs">
                                    <span className="px-2 py-1 rounded bg-slate-700 text-slate-300">
                                      {q.timeSeconds}s
                                    </span>
                                    <span className="px-2 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                                      {q.points} pts
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No questions currently in this difficulty.</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 3: PUBLISH ASSESSMENT */}
        {/* ============================================================ */}
        {tab === 'publish' && (
          <div className="space-y-8 max-w-5xl">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Publish Assessment</h2>
              <p className="text-sm text-slate-400">
                Choose strictly between <strong>Selected Questions</strong> or <strong>Random Questions</strong>.
              </p>
            </div>

            {publishFeedback && (
              <div
                className={`p-4 rounded-xl text-sm font-medium ${
                  publishFeedback.includes('Successfully')
                    ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-300'
                    : 'bg-rose-950/80 border border-rose-500/50 text-rose-300'
                }`}
              >
                {publishFeedback}
              </div>
            )}

            <form onSubmit={handlePublish} className="space-y-6">
              {/* Publish Name (Requirement: Every publish must ask Publish Name) */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-2">
                  Publish Name (Permanently Saved in History)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Class 7 Reasoning Test - September"
                  value={publishName}
                  onChange={(e) => setPublishName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-base text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              {/* Mode Selection (STRICTLY Selected Questions OR Random Questions) */}
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setPublishMode('Selected Questions')}
                  className={`p-5 rounded-2xl border text-left transition-all ${
                    publishMode === 'Selected Questions'
                      ? 'bg-indigo-600/20 border-indigo-500 shadow-xl shadow-indigo-500/10 ring-2 ring-indigo-500'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-base">Selected Questions</span>
                    <Layers className="w-5 h-5 text-indigo-400" />
                  </div>
                  <p className="text-xs text-slate-400">
                    Hand-pick questions across multiple groups and difficulties. Includes Shuffle & Preview with Test.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setPublishMode('Random Questions')}
                  className={`p-5 rounded-2xl border text-left transition-all ${
                    publishMode === 'Random Questions'
                      ? 'bg-indigo-600/20 border-indigo-500 shadow-xl shadow-indigo-500/10 ring-2 ring-indigo-500'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-base">Random Questions</span>
                    <Shuffle className="w-5 h-5 text-indigo-400" />
                  </div>
                  <p className="text-xs text-slate-400">
                    Rule-based adaptive engine automatically selects questions matching student past performance and repetition gap.
                  </p>
                </button>
              </div>

              {/* Target Selection: School -> Class -> Section -> Student */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <h3 className="font-bold text-base text-white">Publish Target Configuration</h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Target School
                    </label>
                    <select
                      value={selectedSchoolId}
                      onChange={(e) => setSelectedSchoolId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                      {schools.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Classes (Leave empty for All Classes)
                    </label>
                    <div className="flex gap-2">
                      {['Class 6', 'Class 7', 'Class 8'].map((cls) => (
                        <button
                          key={cls}
                          type="button"
                          onClick={() => {
                            if (selectedClasses.includes(cls)) {
                              setSelectedClasses(selectedClasses.filter((c) => c !== cls));
                            } else {
                              setSelectedClasses([...selectedClasses, cls]);
                            }
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                            selectedClasses.includes(cls)
                              ? 'bg-indigo-600 border-indigo-400 text-white'
                              : 'bg-slate-800 border-slate-700 text-slate-300'
                          }`}
                        >
                          {cls}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Sections (Leave empty for All Sections)
                    </label>
                    <div className="flex gap-2">
                      {['A', 'B', 'C'].map((sec) => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => {
                            if (selectedSections.includes(sec)) {
                              setSelectedSections(selectedSections.filter((s) => s !== sec));
                            } else {
                              setSelectedSections([...selectedSections, sec]);
                            }
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                            selectedSections.includes(sec)
                              ? 'bg-indigo-600 border-indigo-400 text-white'
                              : 'bg-slate-800 border-slate-700 text-slate-300'
                          }`}
                        >
                          Sec {sec}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Availability Window: Start Date, Start Time, End Date, End Time */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <h3 className="font-bold text-base text-white">Test Availability Window</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">Start Date</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">Start Time</label>
                    <input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">End Date</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">End Time</label>
                    <input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Conditional Mode Config */}
              {publishMode === 'Selected Questions' ? (
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-base text-white">Selected Questions Bank Picker</h3>
                      <p className="text-xs text-slate-400">
                        Selected: {selectedQuestionsForPublish.length} questions
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      {/* Shuffle Questions Checkbox */}
                      <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-300">
                        <input
                          type="checkbox"
                          checked={shuffleQuestions}
                          onChange={(e) => setShuffleQuestions(e.target.checked)}
                          className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-800 border-slate-700"
                        />
                        Shuffle Questions for each student
                      </label>

                      {/* Preview with Test Button */}
                      <button
                        type="button"
                        disabled={selectedQuestionsForPublish.length === 0}
                        onClick={() => setTab('preview_test')}
                        className="px-3.5 py-1.5 rounded-xl bg-indigo-950 text-indigo-300 border border-indigo-700/80 hover:bg-indigo-900 flex items-center gap-1.5 text-xs font-medium transition-all disabled:opacity-40"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Preview with Test
                      </button>
                    </div>
                  </div>

                  {/* List of selectable questions */}
                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {allQuestions.map((q) => {
                      const isChecked = selectedQuestionsForPublish.includes(q.id);
                      return (
                        <div
                          key={q.id}
                          onClick={() => {
                            if (isChecked) {
                              setSelectedQuestionsForPublish(
                                selectedQuestionsForPublish.filter((id) => id !== q.id)
                              );
                            } else {
                              setSelectedQuestionsForPublish([...selectedQuestionsForPublish, q.id]);
                            }
                          }}
                          className={`p-3.5 rounded-xl border text-sm flex items-center justify-between cursor-pointer transition-all ${
                            isChecked
                              ? 'bg-indigo-950/40 border-indigo-500 text-white'
                              : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              readOnly
                              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-800 border-slate-700"
                            />
                            <div>
                              <p className="font-medium text-white">{q.content}</p>
                              <span className="text-xs text-indigo-400">
                                {q.groupName} &bull; {q.difficulty} &bull; {q.questionType}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 shrink-0 font-mono text-xs">
                            <span className="px-2 py-1 rounded bg-slate-700 text-slate-300">
                              {q.timeSeconds}s
                            </span>
                            <span className="px-2 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                              {q.points} pts
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* Random Questions Config */
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                  <h3 className="font-bold text-base text-white">Random Adaptive Engine Settings</h3>
                  <p className="text-xs text-slate-400">
                    Super Admin specifies the number of questions. The rule-based engine dynamically determines
                    question difficulty (Easy &rarr; Medium &rarr; Hard) and enforces anti-repetition exclusion for each student.
                  </p>
                  <div className="max-w-xs">
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Number of Questions
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={50}
                      value={randomCount}
                      onChange={(e) => setRandomCount(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-300 space-y-1">
                    <p className="font-semibold text-indigo-300">Engine Rule Pipeline:</p>
                    <p>&bull; Fresh student &rarr; Easy difficulty tier</p>
                    <p>&bull; High Easy performance (&gt;=70%) &rarr; Easy or Easy + Medium</p>
                    <p>&bull; High Medium performance (&gt;=70%) &rarr; Medium or Medium + Hard</p>
                    <p>&bull; Hard is the final difficulty level</p>
                    <p>&bull; Anti-repetition gap prevents recently used questions from repeating</p>
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-xl shadow-indigo-600/30 transition-all text-base"
              >
                Publish Test to Target
              </button>
            </form>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 4: PREVIEW WITH TEST (Selected Questions Only) */}
        {/* ============================================================ */}
        {tab === 'preview_test' && (
          <div className="space-y-6 max-w-4xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-mono uppercase text-indigo-400">Super Admin Preview</span>
                <h2 className="text-2xl font-bold tracking-tight">Preview with Test</h2>
                <p className="text-sm text-slate-400">
                  Simulating candidate test experience for {selectedQuestionsForPublish.length} selected questions.
                </p>
              </div>
              <button
                onClick={() => setTab('publish')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-medium transition-all"
              >
                &larr; Back to Publish
              </button>
            </div>

            {selectedQuestionsForPublish.length > 0 ? (
              <div className="space-y-6">
                {(() => {
                  const qId = selectedQuestionsForPublish[previewActiveIndex];
                  const q = allQuestions.find((item) => item.id === qId);
                  if (!q) return null;

                  return (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-xs text-slate-400">
                        <span>Question {previewActiveIndex + 1} of {selectedQuestionsForPublish.length}</span>
                        <span>Configured Timer: {q.timeSeconds}s | Points: {q.points}</span>
                      </div>

                      <FlameMiniGameCanvas
                        questionType={q.questionType}
                        content={q.content}
                        points={q.points}
                        timeRemaining={q.timeSeconds}
                        options={q.options}
                        pairs={q.metadata?.pairs || []}
                        onAnswerSubmit={() => {}}
                        selectedAnswer={null}
                        disabled={false}
                      />

                      <div className="flex items-center justify-between pt-4">
                        <button
                          disabled={previewActiveIndex === 0}
                          onClick={() => setPreviewActiveIndex(previewActiveIndex - 1)}
                          className="px-4 py-2 rounded-xl bg-slate-800 disabled:opacity-40 text-sm"
                        >
                          Previous
                        </button>
                        <button
                          disabled={previewActiveIndex >= selectedQuestionsForPublish.length - 1}
                          onClick={() => setPreviewActiveIndex(previewActiveIndex + 1)}
                          className="px-4 py-2 rounded-xl bg-indigo-600 disabled:opacity-40 text-white text-sm"
                        >
                          Next Preview Question &rarr;
                        </button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            ) : (
              <p className="text-slate-400">No questions selected for preview.</p>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 5: PUBLISH HISTORY */}
        {/* ============================================================ */}
        {tab === 'history' && (
          <div className="space-y-6 max-w-6xl">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Publish History</h2>
              <p className="text-sm text-slate-400">
                Permanent historical records showing exactly who completed and who did not complete.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* History Table */}
              <div className="lg:col-span-2 space-y-3">
                {historyList.map((hist) => (
                  <div
                    key={hist.id}
                    onClick={() => viewHistoryDetail(hist.publishId)}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer flex items-center justify-between transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2.5 py-0.5 rounded-full font-mono bg-indigo-950 text-indigo-400 border border-indigo-800">
                          {hist.publishMode}
                        </span>
                        <span className="text-xs text-slate-400">{hist.date} at {hist.time}</span>
                      </div>
                      <h4 className="font-bold text-base text-white mt-1">{hist.publishName}</h4>
                      <p className="text-xs text-slate-400">
                        {hist.schoolName} &bull; {hist.classes?.join(', ')} &bull; {hist.totalRecipients} Recipients
                      </p>
                    </div>

                    <div className="flex items-center gap-4 text-xs font-mono">
                      <div className="text-right">
                        <span className="text-emerald-400 block font-bold">{hist.completedCount} Completed</span>
                        <span className="text-rose-400 block">{hist.totalRecipients - hist.completedCount} Incomplete</span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                ))}
              </div>

              {/* History Drill-down Details */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl h-fit">
                <h3 className="font-bold text-base mb-4">Historical Audit Drill-Down</h3>
                {selectedHistoryDetail ? (
                  <div className="space-y-4 text-sm">
                    <div>
                      <span className="text-xs text-slate-400 block">Assessment</span>
                      <strong className="text-white text-base">{selectedHistoryDetail.publishName}</strong>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 rounded bg-slate-800/80">
                        <span className="text-slate-400 block">Date</span>
                        <span className="text-white font-bold">{selectedHistoryDetail.date}</span>
                      </div>
                      <div className="p-2 rounded bg-slate-800/80">
                        <span className="text-slate-400 block">School</span>
                        <span className="text-white font-bold">{selectedHistoryDetail.schoolName}</span>
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-800">
                      <h5 className="font-bold text-xs uppercase tracking-wider text-emerald-400">
                        Who Completed ({selectedHistoryDetail.completedStudents?.length || 0})
                      </h5>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {selectedHistoryDetail.completedStudents?.map((s: any) => (
                          <div key={s.studentId} className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/40 text-xs flex justify-between">
                            <span>{s.studentName} ({s.className})</span>
                            <span className="font-mono text-emerald-400 font-bold">{s.scoreOutOf100}/100</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-800">
                      <h5 className="font-bold text-xs uppercase tracking-wider text-rose-400">
                        Who Did Not Complete ({selectedHistoryDetail.notCompletedStudents?.length || 0})
                      </h5>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {selectedHistoryDetail.notCompletedStudents?.map((s: any) => (
                          <div key={s.studentId} className="p-2 rounded-lg bg-rose-950/30 border border-rose-800/40 text-xs flex justify-between">
                            <span>{s.studentName} ({s.className})</span>
                            <span className="font-mono text-rose-400">{s.status}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Click any publish entry on the left to review who completed vs. incomplete.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 6: REPORTS & STUDENT TEST TIMELINE */}
        {/* ============================================================ */}
        {tab === 'reports' && (
          <div className="space-y-6 max-w-6xl">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Reports & Student Timeline</h2>
              <p className="text-sm text-slate-400">
                Flow: Reports &rarr; School List &rarr; Select School &rarr; Student List &rarr; Detailed Question Report & Timeline
              </p>
            </div>

            {/* School selector & Search filter */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs uppercase font-bold text-slate-400">Select School:</span>
                <select
                  value={reportSchoolId}
                  onChange={(e) => setReportSchoolId(e.target.value)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none font-medium"
                >
                  {schools.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 max-w-md w-full sm:w-auto">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search student, admission #, or App ID..."
                  value={reportSearch}
                  onChange={(e) => setReportSearch(e.target.value)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>

            {/* Student List & Detailed Report */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Student list */}
              <div className="space-y-2">
                <h3 className="font-bold text-base text-white">Student Roster ({reportStudents.length})</h3>
                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                  {reportStudents.map((stu) => (
                    <div
                      key={stu.id}
                      onClick={() => viewStudentReportDetail(stu.uniqueStudentId)}
                      className={`p-3.5 rounded-xl border cursor-pointer text-sm transition-all ${
                        selectedStudentReport?.student?.uniqueStudentId === stu.uniqueStudentId
                          ? 'bg-indigo-950/60 border-indigo-500 text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <strong className="text-white">{stu.studentName}</strong>
                        <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                          {stu.className} - {stu.section}
                        </span>
                      </div>
                      <p className="text-xs text-indigo-400 font-mono mt-1">ID: {stu.uniqueStudentId}</p>
                      <p className="text-xs text-slate-500">Adm: {stu.schoolAdmissionNumber}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Individual Student Report & Timeline */}
              <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-6">
                {selectedStudentReport ? (
                  <div className="space-y-6">
                    {/* Header profile */}
                    <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white">{selectedStudentReport.student?.studentName}</h3>
                        <p className="text-xs text-slate-400">
                          {selectedStudentReport.student?.className} ({selectedStudentReport.student?.section}) &bull;{' '}
                          {selectedStudentReport.student?.schoolName}
                        </p>
                      </div>
                      <div className="text-right font-mono text-xs">
                        <span className="text-indigo-400 block font-bold">
                          App ID: {selectedStudentReport.student?.uniqueStudentId}
                        </span>
                        <span className="text-slate-500">
                          Adm: {selectedStudentReport.student?.schoolAdmissionNumber}
                        </span>
                      </div>
                    </div>

                    {/* Timeline section */}
                    <div className="space-y-4">
                      <h4 className="font-bold text-sm uppercase tracking-wider text-slate-400">
                        Student Test History Timeline
                      </h4>

                      {selectedStudentReport.timeline && selectedStudentReport.timeline.length > 0 ? (
                        selectedStudentReport.timeline.map((item: any, idx: number) => (
                          <div
                            key={idx}
                            className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/60 space-y-4"
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="text-xs text-indigo-400 font-mono">{item.date}</span>
                                <h5 className="font-bold text-base text-white">{item.testName}</h5>
                              </div>
                              <div className="flex items-center gap-3">
                                <span
                                  className={`text-xs px-2.5 py-1 rounded-full font-bold uppercase ${
                                    item.status === 'COMPLETED'
                                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                      : 'bg-rose-950 text-rose-400 border border-rose-800'
                                  }`}
                                >
                                  {item.status}
                                </span>
                                <span className="font-mono text-lg font-bold text-white">
                                  {item.scoreOutOf100} / 100
                                </span>
                              </div>
                            </div>

                            {/* Question Level Drill-Down: answers, correct/wrong, points, time taken */}
                            <div className="pt-3 border-t border-slate-700/60 space-y-2">
                              <span className="text-xs font-semibold text-slate-400 block">
                                Question Breakdown & Performance:
                              </span>
                              <div className="space-y-2">
                                {item.questions?.map((q: any, qIdx: number) => (
                                  <div
                                    key={qIdx}
                                    className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                                  >
                                    <div className="space-y-1">
                                      <p className="font-medium text-slate-200">{q.content}</p>
                                      <div className="flex flex-wrap items-center gap-2 text-slate-400">
                                        <span>Student Ans: <strong className="text-white">{JSON.stringify(q.studentAnswer) || 'None'}</strong></span>
                                        <span>&bull;</span>
                                        <span>Correct Ans: <strong className="text-emerald-400">{JSON.stringify(q.correctAnswer)}</strong></span>
                                      </div>
                                    </div>

                                    <div className="flex items-center gap-3 shrink-0 font-mono">
                                      <span className="text-slate-400">Time: {q.timeTakenSeconds}s / {q.timeAllowedSeconds}s</span>
                                      <span
                                        className={`px-2 py-0.5 rounded font-bold ${
                                          q.isCorrect
                                            ? 'bg-emerald-950 text-emerald-300'
                                            : 'bg-rose-950 text-rose-300'
                                        }`}
                                      >
                                        {q.isCorrect ? `+${q.earnedPoints} pts` : '0 pts'}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-500 italic">No assessment attempts recorded for this student yet.</p>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">
                    Select a student from the left panel to review their comprehensive assessment score cards, question-level logs, and timeline.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
