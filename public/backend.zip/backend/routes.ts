import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from './storage.ts';
import { generateToken, authenticate, requireRole, checkSchoolIsolation } from './middleware/auth.ts';
import {
  computeStudentInsights,
  selectRandomQuestionsForRuleEngine,
} from './services/randomEngine.ts';
import {
  User,
  School,
  QuestionGroup,
  Question,
  PublishedTest,
  StudentTestAssignment,
  PublishHistoryRecord,
  QuestionAttemptLog,
} from './types.ts';

const router = express.Router();

// ==========================================
// 1. AUTHENTICATION & PASSWORD MANAGEMENT
// ==========================================

// Login (Supports Super Admin, School Admin, Student)
router.post('/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const user = db.getState().users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase());
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const isMatch = bcrypt.compareSync(password, user.passwordHash);
  if (!isMatch) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const token = generateToken({
    userId: user.id,
    username: user.username,
    role: user.role,
    schoolId: user.schoolId,
    schoolName: user.schoolName,
    studentId: user.uniqueStudentId,
  });

  return res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      mustChangePassword: user.mustChangePassword,
      schoolId: user.schoolId,
      schoolName: user.schoolName,
      studentName: user.studentName,
      className: user.className,
      section: user.section,
      uniqueStudentId: user.uniqueStudentId,
    },
  });
});

// Force Password Change (Mandatory on first login)
router.post('/auth/change-password', authenticate, (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.trim().length < 4) {
    return res.status(400).json({ error: 'New password must be at least 4 characters long' });
  }

  const state = db.getState();
  const user = state.users.find((u) => u.id === req.user!.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Prevent reusing default initial password
  if (user.role === 'super_admin' && newPassword === 'Roll_Call') {
    return res.status(400).json({ error: 'New password cannot be the default Roll_Call password' });
  }
  if (newPassword === user.username) {
    return res.status(400).json({ error: 'New password cannot be identical to your ID/username' });
  }

  // Update user
  db.mutate((st) => {
    const target = st.users.find((u) => u.id === req.user!.userId);
    if (target) {
      const salt = bcrypt.genSaltSync(10);
      target.passwordHash = bcrypt.hashSync(newPassword, salt);
      target.mustChangePassword = false;
      target.updatedAt = new Date().toISOString();
    }
  });

  return res.json({ success: true, message: 'Password updated successfully' });
});

// Get Current User Profile
router.get('/auth/me', authenticate, (req: Request, res: Response) => {
  const user = db.getState().users.find((u) => u.id === req.user!.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  return res.json({
    id: user.id,
    username: user.username,
    role: user.role,
    mustChangePassword: user.mustChangePassword,
    schoolId: user.schoolId,
    schoolName: user.schoolName,
    studentName: user.studentName,
    className: user.className,
    section: user.section,
    uniqueStudentId: user.uniqueStudentId,
  });
});

// ==========================================
// 2. SUPER ADMIN: SCHOOL WORKSPACE MANAGEMENT
// ==========================================

// Create School
router.post('/schools', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { name, code } = req.body;
  if (!name || !code) {
    return res.status(400).json({ error: 'School name and code are required' });
  }

  const newSchool: School = {
    id: `sch_${Date.now()}`,
    name: name.trim(),
    code: code.trim().toUpperCase(),
    createdAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.schools.push(newSchool);
  });

  return res.status(201).json(newSchool);
});

// List Schools
router.get('/schools', authenticate, (req: Request, res: Response) => {
  const user = req.user!;
  if (user.role === 'super_admin') {
    return res.json(db.getState().schools);
  }
  // School Admin or Student can only view their own school
  const mySchool = db.getState().schools.filter((s) => s.id === user.schoolId);
  return res.json(mySchool);
});

// Create School Admin (Username = Admin ID, Password = Admin ID)
router.post('/schools/:schoolId/admins', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { schoolId } = req.params;
  const school = db.getState().schools.find((s) => s.id === schoolId);
  if (!school) return res.status(404).json({ error: 'School not found' });

  // Generate unique Admin ID: e.g. ADM-SCH-XXXX
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const adminId = `ADM-${school.code}-${randomSuffix}`;

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(adminId, salt);

  const newAdmin: User = {
    id: `usr_${Date.now()}`,
    username: adminId,
    role: 'school_admin',
    passwordHash,
    mustChangePassword: true,
    schoolId: school.id,
    schoolName: school.name,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.users.push(newAdmin);
  });

  return res.status(201).json({
    adminId,
    username: adminId,
    initialPassword: adminId,
    schoolName: school.name,
    mustChangePassword: true,
  });
});

// Create Another Super Admin
router.post('/super-admins', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  const existing = db.getState().users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'Username already taken' });
  }

  const salt = bcrypt.genSaltSync(10);
  const newSuperAdmin: User = {
    id: `usr_sa_${Date.now()}`,
    username: username.trim(),
    role: 'super_admin',
    passwordHash: bcrypt.hashSync(password, salt),
    mustChangePassword: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.users.push(newSuperAdmin);
  });

  return res.status(201).json({ success: true, username: newSuperAdmin.username });
});

// ==========================================
// 3. STUDENT MANAGEMENT (SUPER ADMIN)
// ==========================================

// Create Student
router.post('/students', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const {
    studentName,
    className,
    section,
    schoolAdmissionNumber,
    schoolId,
  } = req.body;

  if (!studentName || !className || !section || !schoolAdmissionNumber || !schoolId) {
    return res.status(400).json({ error: 'All student fields are required' });
  }

  const school = db.getState().schools.find((s) => s.id === schoolId);
  if (!school) return res.status(404).json({ error: 'School not found' });

  // Unique App Number / Student ID
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const cleanClass = className.replace(/[^0-9]/g, '') || '0';
  const uniqueStudentId = `STU-${cleanClass}${section.toUpperCase()}-${randomSuffix}`;

  const salt = bcrypt.genSaltSync(10);
  const newStudent: User = {
    id: `usr_stu_${Date.now()}`,
    username: uniqueStudentId,
    role: 'student',
    passwordHash: bcrypt.hashSync(uniqueStudentId, salt),
    mustChangePassword: true,
    schoolId: school.id,
    schoolName: school.name,
    studentName: studentName.trim(),
    className: className.trim(),
    section: section.trim().toUpperCase(),
    schoolAdmissionNumber: schoolAdmissionNumber.trim(),
    uniqueStudentId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.users.push(newStudent);
  });

  return res.status(201).json({
    student: newStudent,
    credentials: {
      username: uniqueStudentId,
      initialPassword: uniqueStudentId,
    },
  });
});

// List Students (Filtered by school, class, section, search)
router.get('/students', authenticate, (req: Request, res: Response) => {
  const { schoolId, className, section, search } = req.query as {
    schoolId?: string;
    className?: string;
    section?: string;
    search?: string;
  };

  let list = db.getState().users.filter((u) => u.role === 'student');

  // Enforce access control
  if (req.user!.role === 'school_admin' || req.user!.role === 'student') {
    list = list.filter((s) => s.schoolId === req.user!.schoolId);
  } else if (schoolId) {
    list = list.filter((s) => s.schoolId === schoolId);
  }

  if (className) {
    list = list.filter((s) => s.className?.toLowerCase() === className.toLowerCase());
  }
  if (section) {
    list = list.filter((s) => s.section?.toUpperCase() === section.toUpperCase());
  }
  if (search) {
    const q = search.toLowerCase();
    list = list.filter(
      (s) =>
        s.studentName?.toLowerCase().includes(q) ||
        s.schoolAdmissionNumber?.toLowerCase().includes(q) ||
        s.uniqueStudentId?.toLowerCase().includes(q)
    );
  }

  return res.json(list);
});

// ==========================================
// 4. QUESTION GROUPS & QUESTION BANK
// ==========================================

// Create Question Group
router.post('/question-groups', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { name, description } = req.body;
  if (!name) return res.status(400).json({ error: 'Group name is required' });

  const newGroup: QuestionGroup = {
    id: `grp_${Date.now()}`,
    name: name.trim(),
    description: description?.trim() || '',
    createdAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.questionGroups.push(newGroup);
  });

  return res.status(201).json(newGroup);
});

// List Question Groups with Breakdown (View Mode: Easy, Medium, Hard counts)
router.get('/question-groups', authenticate, (req: Request, res: Response) => {
  const state = db.getState();
  const summary = state.questionGroups.map((grp) => {
    const groupQuestions = state.questions.filter((q) => q.groupId === grp.id);
    const easy = groupQuestions.filter((q) => q.difficulty === 'Easy');
    const medium = groupQuestions.filter((q) => q.difficulty === 'Medium');
    const hard = groupQuestions.filter((q) => q.difficulty === 'Hard');

    return {
      id: grp.id,
      name: grp.name,
      description: grp.description,
      breakdown: {
        Easy: {
          count: easy.length,
          questions: easy.map((q) => ({ id: q.id, content: q.content, timeSeconds: q.timeSeconds, points: q.points, questionType: q.questionType })),
        },
        Medium: {
          count: medium.length,
          questions: medium.map((q) => ({ id: q.id, content: q.content, timeSeconds: q.timeSeconds, points: q.points, questionType: q.questionType })),
        },
        Hard: {
          count: hard.length,
          questions: hard.map((q) => ({ id: q.id, content: q.content, timeSeconds: q.timeSeconds, points: q.points, questionType: q.questionType })),
        },
      },
    };
  });

  return res.json(summary);
});

// Create Question inside Group -> Difficulty
router.post('/questions', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const {
    groupId,
    difficulty,
    questionType,
    content,
    timeSeconds,
    points,
    options,
    correctAnswer,
    metadata,
  } = req.body;

  if (!groupId || !difficulty || !questionType || !content || timeSeconds == null || points == null) {
    return res.status(400).json({ error: 'Missing mandatory question fields' });
  }

  const group = db.getState().questionGroups.find((g) => g.id === groupId);
  if (!group) return res.status(404).json({ error: 'Question Group not found' });

  const newQuestion: Question = {
    id: `q_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    groupId,
    groupName: group.name,
    difficulty,
    questionType,
    content: content.trim(),
    timeSeconds: Number(timeSeconds),
    points: Number(points),
    options: options || [],
    correctAnswer,
    metadata: metadata || {},
    createdAt: new Date().toISOString(),
  };

  db.mutate((st) => {
    st.questions.push(newQuestion);
  });

  return res.status(201).json(newQuestion);
});

// List All Questions (for Selection in Selected Questions Mode)
router.get('/questions', authenticate, (req: Request, res: Response) => {
  const { groupId, difficulty } = req.query as { groupId?: string; difficulty?: string };
  let list = db.getState().questions;
  if (groupId) list = list.filter((q) => q.groupId === groupId);
  if (difficulty) list = list.filter((q) => q.difficulty === difficulty);
  return res.json(list);
});

// ==========================================
// 5. TEST PUBLISHING ENGINE
// ==========================================

// Publish Test (Mode: 'Selected Questions' OR 'Random Questions')
router.post('/publish', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const {
    publishName,
    publishMode,
    target, // { schoolId, classes, sections, studentIds }
    startDate,
    startTime,
    endDate,
    endTime,
    selectedQuestionIds, // for Selected Questions
    randomCount, // for Random Questions
    shuffle,
  } = req.body;

  if (!publishName || !publishMode || !target || !target.schoolId || !startDate || !endDate) {
    return res.status(400).json({ error: 'Publish parameters missing' });
  }

  if (publishMode !== 'Selected Questions' && publishMode !== 'Random Questions') {
    return res.status(400).json({ error: 'Publish mode must be strictly "Selected Questions" or "Random Questions"' });
  }

  const school = db.getState().schools.find((s) => s.id === target.schoolId);
  if (!school) return res.status(404).json({ error: 'Target school not found' });

  // Resolve target students
  let candidateStudents = db.getState().users.filter(
    (u) => u.role === 'student' && u.schoolId === target.schoolId
  );

  if (target.classes && target.classes.length > 0) {
    candidateStudents = candidateStudents.filter((s) => target.classes.includes(s.className!));
  }
  if (target.sections && target.sections.length > 0) {
    candidateStudents = candidateStudents.filter((s) => target.sections.includes(s.section!));
  }
  if (target.studentIds && target.studentIds.length > 0) {
    candidateStudents = candidateStudents.filter((s) => target.studentIds.includes(s.uniqueStudentId!));
  }

  if (candidateStudents.length === 0) {
    return res.status(400).json({ error: 'No matching students found in selected publish target' });
  }

  const publishedTestId = `pub_${Date.now()}`;
  const allQuestions = db.getState().questions;

  const newPublish: PublishedTest = {
    id: publishedTestId,
    publishName: publishName.trim(),
    publishMode,
    target: {
      ...target,
      schoolName: school.name,
    },
    startDate,
    startTime: startTime || '00:00',
    endDate,
    endTime: endTime || '23:59',
    questionIds: selectedQuestionIds || [],
    randomCount: randomCount ? Number(randomCount) : undefined,
    shuffle: Boolean(shuffle),
    createdAt: new Date().toISOString(),
    createdBy: req.user!.username,
  };

  const newAssignments: StudentTestAssignment[] = [];

  // Create assignments for every target student
  for (const student of candidateStudents) {
    let studentQuestionList: Question[] = [];

    if (publishMode === 'Selected Questions') {
      // Pick selected questions
      const pool = allQuestions.filter((q) => selectedQuestionIds.includes(q.id));
      studentQuestionList = [...pool];
      // Apply Shuffle Questions if enabled: each student gets their own random order
      if (shuffle) {
        studentQuestionList.sort(() => 0.5 - Math.random());
      }
    } else {
      // Random Questions Engine (Rule-based, per student history)
      const insights = computeStudentInsights(student.uniqueStudentId!, db.getState().assignments);
      studentQuestionList = selectRandomQuestionsForRuleEngine(
        Number(randomCount) || 5,
        allQuestions,
        insights
      );
    }

    const questionLogs: QuestionAttemptLog[] = studentQuestionList.map((q) => ({
      questionId: q.id,
      groupName: q.groupName,
      difficulty: q.difficulty,
      questionType: q.questionType,
      content: q.content,
      points: q.points,
      studentAnswer: null,
      correctAnswer: q.correctAnswer,
      isCorrect: false,
      timeAllowedSeconds: q.timeSeconds,
      timeTakenSeconds: 0,
      earnedPoints: 0,
    }));

    newAssignments.push({
      id: `asg_${Date.now()}_${student.uniqueStudentId}`,
      publishedTestId,
      publishName: publishName.trim(),
      studentId: student.uniqueStudentId!,
      studentName: student.studentName!,
      schoolId: school.id,
      schoolName: school.name,
      className: student.className!,
      section: student.section!,
      status: 'NOT_STARTED',
      totalQuestions: questionLogs.length,
      correctCount: 0,
      wrongCount: 0,
      totalPointsEarned: 0,
      scoreOutOf100: 0,
      totalTimeTakenSeconds: 0,
      questions: questionLogs,
    });
  }

  // Create permanent history record
  const historyRecord: PublishHistoryRecord = {
    id: `hist_${Date.now()}`,
    publishId: publishedTestId,
    publishName: publishName.trim(),
    date: startDate,
    time: startTime || new Date().toLocaleTimeString(),
    schoolId: school.id,
    schoolName: school.name,
    classes: target.classes || ['All Classes'],
    sections: target.sections || ['All Sections'],
    totalRecipients: candidateStudents.length,
    publishMode,
    assignedQuestionsCount: publishMode === 'Selected Questions' ? (selectedQuestionIds?.length || 0) : (randomCount || 0),
    completedCount: 0,
    incompleteCount: 0,
    studentsStatus: candidateStudents.map((s) => ({
      studentId: s.uniqueStudentId!,
      studentName: s.studentName!,
      className: s.className!,
      section: s.section!,
      status: 'NOT_STARTED',
    })),
  };

  db.mutate((st) => {
    st.publishedTests.push(newPublish);
    st.assignments.push(...newAssignments);
    st.publishHistory.push(historyRecord);
  });

  return res.status(201).json({
    success: true,
    publishedTestId,
    assignedStudentCount: candidateStudents.length,
    message: `Test "${publishName}" successfully published to ${candidateStudents.length} student(s)`,
  });
});

// ==========================================
// 6. STUDENT TEST ENGINE (CARDS, TIMER, ONE-TIME ATTEMPT)
// ==========================================

// Get Assigned Test Cards for Student
router.get('/student/tests', authenticate, requireRole('student'), (req: Request, res: Response) => {
  const studentId = req.user!.studentId || req.user!.username;
  const assignments = db.getState().assignments.filter((a) => a.studentId === studentId);
  const publishedTests = db.getState().publishedTests;

  const now = new Date();

  const testCards = assignments.map((asg) => {
    const pub = publishedTests.find((p) => p.id === asg.publishedTestId);
    let isExpired = false;
    let isUpcoming = false;

    if (pub) {
      const startDateTime = new Date(`${pub.startDate}T${pub.startTime || '00:00'}`);
      const endDateTime = new Date(`${pub.endDate}T${pub.endTime || '23:59'}`);
      if (now < startDateTime) isUpcoming = true;
      if (now > endDateTime) isExpired = true;
    }

    return {
      assignmentId: asg.id,
      publishedTestId: asg.publishedTestId,
      publishName: asg.publishName,
      status: asg.status,
      totalQuestions: asg.totalQuestions,
      scoreOutOf100: asg.scoreOutOf100,
      totalPointsEarned: asg.totalPointsEarned,
      startDate: pub?.startDate,
      startTime: pub?.startTime,
      endDate: pub?.endDate,
      endTime: pub?.endTime,
      isExpired,
      isUpcoming,
      canStart: asg.status === 'NOT_STARTED' && !isExpired && !isUpcoming,
    };
  });

  return res.json(testCards);
});

// Start Test Attempt (ONE-TIME CONSUMED IMMEDIATELY)
router.post('/student/tests/:assignmentId/start', authenticate, requireRole('student'), (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const studentId = req.user!.studentId || req.user!.username;

  const state = db.getState();
  const assignment = state.assignments.find((a) => a.id === assignmentId && a.studentId === studentId);

  if (!assignment) {
    return res.status(404).json({ error: 'Assigned test not found' });
  }

  // CRITICAL: Cannot reopen if completed or locked
  if (assignment.status === 'COMPLETED' || assignment.status === 'LOCKED_INCOMPLETE') {
    return res.status(403).json({
      error: `Test attempt has already been consumed. Status is ${assignment.status}. Cannot reopen.`,
    });
  }

  // Check availability window
  const pub = state.publishedTests.find((p) => p.id === assignment.publishedTestId);
  if (pub) {
    const now = new Date();
    const endDateTime = new Date(`${pub.endDate}T${pub.endTime || '23:59'}`);
    if (now > endDateTime) {
      return res.status(403).json({ error: 'Test availability has expired. Cannot start.' });
    }
  }

  // Immediately transition to IN_PROGRESS
  db.mutate((st) => {
    const target = st.assignments.find((a) => a.id === assignmentId);
    if (target && target.status === 'NOT_STARTED') {
      target.status = 'IN_PROGRESS';
      target.startedAt = new Date().toISOString();
    }
    // Update history record
    const hist = st.publishHistory.find((h) => h.publishId === target?.publishedTestId);
    if (hist) {
      const studentStatus = hist.studentsStatus.find((s) => s.studentId === studentId);
      if (studentStatus) studentStatus.status = 'IN_PROGRESS';
    }
  });

  // Provide questions without exposing correct answers
  const sanitizedQuestions = assignment.questions.map((q) => {
    const fullQ = state.questions.find((fq) => fq.id === q.questionId);
    return {
      questionId: q.questionId,
      groupName: q.groupName,
      difficulty: q.difficulty,
      questionType: q.questionType,
      content: q.content,
      points: q.points,
      timeAllowedSeconds: q.timeAllowedSeconds,
      options: fullQ?.options || [],
      metadata: fullQ?.metadata || {},
      pairs: fullQ?.metadata?.pairs || (fullQ?.correctAnswer && typeof fullQ.correctAnswer === 'object' ? Object.keys(fullQ.correctAnswer).map(k => ({ left: k, right: (fullQ.correctAnswer as any)[k] })) : []),
    };
  });

  return res.json({
    assignmentId: assignment.id,
    publishName: assignment.publishName,
    status: 'IN_PROGRESS',
    questions: sanitizedQuestions,
  });
});

// Exit / Abandon Test -> LOCKED / INCOMPLETE (Cannot reopen)
router.post('/student/tests/:assignmentId/lock', authenticate, requireRole('student'), (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const studentId = req.user!.studentId || req.user!.username;

  db.mutate((st) => {
    const target = st.assignments.find((a) => a.id === assignmentId && a.studentId === studentId);
    if (target && target.status === 'IN_PROGRESS') {
      target.status = 'LOCKED_INCOMPLETE';
      target.lockedAt = new Date().toISOString();

      // Recalculate score on incomplete state
      let totalPoints = 0;
      let possiblePoints = 0;
      for (const q of target.questions) {
        possiblePoints += q.points;
        totalPoints += q.earnedPoints;
      }
      target.scoreOutOf100 = possiblePoints > 0 ? Math.round((totalPoints / possiblePoints) * 100) : 0;

      // Update publish history
      const hist = st.publishHistory.find((h) => h.publishId === target.publishedTestId);
      if (hist) {
        hist.incompleteCount++;
        const sStatus = hist.studentsStatus.find((s) => s.studentId === studentId);
        if (sStatus) {
          sStatus.status = 'LOCKED_INCOMPLETE';
          sStatus.scoreOutOf100 = target.scoreOutOf100;
        }
      }
    }
  });

  return res.json({ success: true, status: 'LOCKED_INCOMPLETE', message: 'Test has been locked.' });
});

// Complete Question and Submit Test
router.post('/student/tests/:assignmentId/submit', authenticate, requireRole('student'), (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const { answers } = req.body as {
    answers: {
      questionId: string;
      answer: any;
      timeTakenSeconds: number;
    }[];
  };

  const studentId = req.user!.studentId || req.user!.username;
  const state = db.getState();
  const assignment = state.assignments.find((a) => a.id === assignmentId && a.studentId === studentId);

  if (!assignment) return res.status(404).json({ error: 'Assignment not found' });
  if (assignment.status === 'COMPLETED' || assignment.status === 'LOCKED_INCOMPLETE') {
    return res.status(403).json({ error: `Cannot submit. Test status is already ${assignment.status}.` });
  }

  let correctCount = 0;
  let wrongCount = 0;
  let earnedPointsTotal = 0;
  let possiblePointsTotal = 0;
  let totalTime = 0;

  db.mutate((st) => {
    const target = st.assignments.find((a) => a.id === assignmentId)!;

    for (const q of target.questions) {
      possiblePointsTotal += q.points;
      const submitted = answers.find((ans) => ans.questionId === q.questionId);

      if (submitted) {
        q.studentAnswer = submitted.answer;
        q.timeTakenSeconds = submitted.timeTakenSeconds || 0;
        totalTime += q.timeTakenSeconds;

        // Check correctness based on question type
        let isCorrect = false;
        if (q.questionType === 'Match') {
          // Compare object mappings
          if (typeof q.correctAnswer === 'object' && typeof submitted.answer === 'object') {
            const correctKeys = Object.keys(q.correctAnswer);
            isCorrect = correctKeys.length > 0 && correctKeys.every(
              (k) => q.correctAnswer[k] === submitted.answer[k]
            );
          }
        } else {
          isCorrect =
            String(submitted.answer || '').trim().toLowerCase() ===
            String(q.correctAnswer || '').trim().toLowerCase();
        }

        q.isCorrect = isCorrect;
        if (isCorrect) {
          correctCount++;
          q.earnedPoints = q.points;
          earnedPointsTotal += q.points;
        } else {
          wrongCount++;
          q.earnedPoints = 0;
        }
      } else {
        wrongCount++;
      }
    }

    target.status = 'COMPLETED';
    target.completedAt = new Date().toISOString();
    target.correctCount = correctCount;
    target.wrongCount = wrongCount;
    target.totalPointsEarned = earnedPointsTotal;
    target.totalTimeTakenSeconds = totalTime;
    // 100-point normalized base score
    target.scoreOutOf100 = possiblePointsTotal > 0 ? Math.round((earnedPointsTotal / possiblePointsTotal) * 100) : 0;

    // Update permanent history
    const hist = st.publishHistory.find((h) => h.publishId === target.publishedTestId);
    if (hist) {
      hist.completedCount++;
      const sStatus = hist.studentsStatus.find((s) => s.studentId === studentId);
      if (sStatus) {
        sStatus.status = 'COMPLETED';
        sStatus.completionDate = new Date().toISOString().split('T')[0];
        sStatus.completionTime = new Date().toLocaleTimeString();
        sStatus.scoreOutOf100 = target.scoreOutOf100;
      }
    }
  });

  return res.json({
    status: 'COMPLETED',
    scoreOutOf100: possiblePointsTotal > 0 ? Math.round((earnedPointsTotal / possiblePointsTotal) * 100) : 0,
    totalPointsEarned: earnedPointsTotal,
    correctCount,
    wrongCount,
    totalTimeTakenSeconds: totalTime,
  });
});

// ==========================================
// 7. PUBLISH HISTORY & DRILL-DOWN
// ==========================================

// Get All Publish History
router.get('/publish-history', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  return res.json(db.getState().publishHistory);
});

// Get Specific Publish History Record with Who Completed & Who Did Not Complete
router.get('/publish-history/:publishId', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { publishId } = req.params;
  const history = db.getState().publishHistory.find((h) => h.publishId === publishId);
  if (!history) return res.status(404).json({ error: 'Publish history record not found' });

  const completedStudents = history.studentsStatus.filter((s) => s.status === 'COMPLETED');
  const notCompletedStudents = history.studentsStatus.filter((s) => s.status !== 'COMPLETED');

  return res.json({
    ...history,
    completedStudents,
    notCompletedStudents,
  });
});

// ==========================================
// 8. REPORTS & STUDENT TEST TIMELINE
// ==========================================

// Super Admin Student Reports List (School -> Class -> Section -> Search)
router.get('/reports/schools/:schoolId/students', authenticate, requireRole('super_admin'), (req: Request, res: Response) => {
  const { schoolId } = req.params;
  const { className, section, search } = req.query as { className?: string; section?: string; search?: string };

  let students = db.getState().users.filter((u) => u.role === 'student' && u.schoolId === schoolId);

  if (className) {
    students = students.filter((s) => s.className?.toLowerCase() === className.toLowerCase());
  }
  if (section) {
    students = students.filter((s) => s.section?.toUpperCase() === section.toUpperCase());
  }
  if (search) {
    const q = search.toLowerCase();
    students = students.filter(
      (s) =>
        s.studentName?.toLowerCase().includes(q) ||
        s.schoolAdmissionNumber?.toLowerCase().includes(q) ||
        s.uniqueStudentId?.toLowerCase().includes(q)
    );
  }

  return res.json(students);
});

// Student Individual Report & Timeline
router.get('/reports/students/:studentId', authenticate, (req: Request, res: Response) => {
  const { studentId } = req.params;

  // Student can only access their own report
  if (req.user!.role === 'student' && req.user!.studentId !== studentId && req.user!.username !== studentId) {
    return res.status(403).json({ error: 'Access forbidden: You can only view your own report' });
  }

  const student = db.getState().users.find((u) => u.uniqueStudentId === studentId);
  const assignments = db.getState().assignments.filter((a) => a.studentId === studentId);

  // Timeline entries
  const timeline = assignments.map((a) => ({
    assignmentId: a.id,
    publishedTestId: a.publishedTestId,
    testName: a.publishName,
    status: a.status,
    date: a.completedAt ? a.completedAt.split('T')[0] : a.startedAt ? a.startedAt.split('T')[0] : 'Assigned',
    scoreOutOf100: a.scoreOutOf100,
    totalPointsEarned: a.totalPointsEarned,
    correctCount: a.correctCount,
    wrongCount: a.wrongCount,
    totalTimeTakenSeconds: a.totalTimeTakenSeconds,
    questions: a.questions, // Question-level details: answers, time taken, points, correct/wrong
  }));

  return res.json({
    student: student ? {
      studentName: student.studentName,
      className: student.className,
      section: student.section,
      schoolAdmissionNumber: student.schoolAdmissionNumber,
      uniqueStudentId: student.uniqueStudentId,
      schoolName: student.schoolName,
    } : null,
    timeline,
  });
});

export default router;
