import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  School,
  QuestionGroup,
  Question,
  PublishedTest,
  StudentTestAssignment,
  PublishHistoryRecord,
} from '../types.ts';

// In-memory persistent file storage backup
const DATA_FILE = path.resolve(process.cwd(), 'database_state.json');

export interface DatabaseState {
  users: User[];
  schools: School[];
  questionGroups: QuestionGroup[];
  questions: Question[];
  publishedTests: PublishedTest[];
  assignments: StudentTestAssignment[];
  publishHistory: PublishHistoryRecord[];
}

const DEFAULT_STATE: DatabaseState = {
  users: [],
  schools: [],
  questionGroups: [],
  questions: [],
  publishedTests: [],
  assignments: [],
  publishHistory: [],
};

class StorageAdapter {
  private state: DatabaseState;

  constructor() {
    this.state = this.loadState();
    this.seedDefaultsIfEmpty();
  }

  private loadState(): DatabaseState {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Failed to load database state file, resetting to defaults', e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  private saveState(): void {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.state, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to persist database state', e);
    }
  }

  public getState(): DatabaseState {
    return this.state;
  }

  public mutate(action: (state: DatabaseState) => void): void {
    action(this.state);
    this.saveState();
  }

  private seedDefaultsIfEmpty() {
    // 1. Initial Super Admin check
    const hasSuperAdmin = this.state.users.some((u) => u.role === 'super_admin');
    if (!hasSuperAdmin) {
      const salt = bcrypt.genSaltSync(10);
      const initialPasswordHash = bcrypt.hashSync('Roll_Call', salt);
      const superAdmin: User = {
        id: 'usr_superadmin_01',
        username: 'Rolecall',
        role: 'super_admin',
        passwordHash: initialPasswordHash,
        mustChangePassword: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      this.state.users.push(superAdmin);
    }

    // 2. Default Schools check
    if (this.state.schools.length === 0) {
      const schoolA: School = {
        id: 'sch_greenwood',
        name: 'Greenwood High International School',
        code: 'GWH-001',
        createdAt: new Date().toISOString(),
      };
      const schoolB: School = {
        id: 'sch_oakridge',
        name: 'Oakridge World Academy',
        code: 'OWA-002',
        createdAt: new Date().toISOString(),
      };
      this.state.schools.push(schoolA, schoolB);

      // Create Admin for Greenwood
      const adminIdGreenwood = 'ADM-GWH-789';
      const adminSalt = bcrypt.genSaltSync(10);
      this.state.users.push({
        id: 'usr_adm_gwh',
        username: adminIdGreenwood,
        role: 'school_admin',
        passwordHash: bcrypt.hashSync(adminIdGreenwood, adminSalt),
        mustChangePassword: true,
        schoolId: schoolA.id,
        schoolName: schoolA.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      // Create initial students
      const student1Id = 'STU-701-ALEX';
      this.state.users.push({
        id: 'usr_stu_01',
        username: student1Id,
        role: 'student',
        passwordHash: bcrypt.hashSync(student1Id, adminSalt),
        mustChangePassword: true,
        schoolId: schoolA.id,
        schoolName: schoolA.name,
        studentName: 'Alex Rivera',
        className: 'Class 7',
        section: 'A',
        schoolAdmissionNumber: 'ADM-2026-701',
        uniqueStudentId: student1Id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      const student2Id = 'STU-702-PRIYA';
      this.state.users.push({
        id: 'usr_stu_02',
        username: student2Id,
        role: 'student',
        passwordHash: bcrypt.hashSync(student2Id, adminSalt),
        mustChangePassword: true,
        schoolId: schoolA.id,
        schoolName: schoolA.name,
        studentName: 'Priya Sharma',
        className: 'Class 7',
        section: 'B',
        schoolAdmissionNumber: 'ADM-2026-702',
        uniqueStudentId: student2Id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      const student3Id = 'STU-801-DANIEL';
      this.state.users.push({
        id: 'usr_stu_03',
        username: student3Id,
        role: 'student',
        passwordHash: bcrypt.hashSync(student3Id, adminSalt),
        mustChangePassword: true,
        schoolId: schoolA.id,
        schoolName: schoolA.name,
        studentName: 'Daniel Kim',
        className: 'Class 8',
        section: 'A',
        schoolAdmissionNumber: 'ADM-2026-801',
        uniqueStudentId: student3Id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }

    // 3. Question Groups check
    if (this.state.questionGroups.length === 0) {
      this.state.questionGroups.push(
        { id: 'grp_aptitude', name: 'Aptitude', description: 'Mathematical, logical reasoning & analytical aptitude', createdAt: new Date().toISOString() },
        { id: 'grp_reasoning', name: 'Reasoning', description: 'Pattern matching, emoji deciphering & deduction', createdAt: new Date().toISOString() },
        { id: 'grp_creativity', name: 'Creativity', description: 'Spatial reasoning, match combinations & divergent problem solving', createdAt: new Date().toISOString() },
        { id: 'grp_thinking', name: 'Thinking', description: 'Critical thinking, algebraic logic & multi-step word puzzles', createdAt: new Date().toISOString() }
      );
    }

    // 4. Seed the initial 5 dummy questions if none exist
    if (this.state.questions.length === 0) {
      try {
        const dummyPath = path.resolve(process.cwd(), 'seed/dummy_questions.json');
        if (fs.existsSync(dummyPath)) {
          const raw = fs.readFileSync(dummyPath, 'utf-8');
          const dummyList = JSON.parse(raw);
          for (let i = 0; i < dummyList.length; i++) {
            const item = dummyList[i];
            const groupObj = this.state.questionGroups.find((g) => g.name === item.group);
            this.state.questions.push({
              id: `q_seed_0${i + 1}`,
              groupId: groupObj ? groupObj.id : 'grp_aptitude',
              groupName: item.group,
              difficulty: item.difficulty,
              questionType: item.questionType,
              content: item.content,
              timeSeconds: item.timeSeconds,
              points: item.points,
              options: item.options,
              correctAnswer: item.correctAnswer,
              metadata: item.metadata || {},
              createdAt: new Date().toISOString(),
            });
          }
        }
      } catch (err) {
        console.error('Error seeding dummy questions:', err);
      }
    }

    this.saveState();
  }
}

export const db = new StorageAdapter();
