import mongoose from 'mongoose';
import {
  UserModel,
  SchoolModel,
  QuestionGroupModel,
  QuestionModel,
  PublishedTestModel,
  StudentTestAssignmentModel,
  PublishHistoryModel,
} from '../database/models.ts';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';

export async function connectMongoDB(): Promise<{ uri: string; isConnected: boolean; dbName: string }> {
  try {
    const rawUri = (process.env.MONGO_URI || process.env.MONGODB_URI || '').trim();

    if (!rawUri) {
      throw new Error(
        'Neither MONGO_URI nor MONGODB_URI environment variable is configured.'
      );
    }

    // Enforce target database puzzles_assessment_dev
    let finalUri = rawUri;
    // If URI doesn't have puzzles_assessment_dev in the path before query parameters, inject it
    if (!finalUri.includes('/puzzles_assessment_dev')) {
      if (finalUri.includes('/?')) {
        finalUri = finalUri.replace('/?', '/puzzles_assessment_dev?');
      } else if (finalUri.endsWith('/')) {
        finalUri = finalUri + 'puzzles_assessment_dev';
      } else if (!finalUri.split('?')[0].split('/').pop()) {
        finalUri = finalUri + '/puzzles_assessment_dev';
      }
    }

    // Mask credentials for logs
    const maskedUri = finalUri.replace(/:([^@/]+)@/, ':****@');
    console.log(`[Database] Connecting exclusively to MongoDB Atlas at: ${maskedUri}`);

    await mongoose.connect(finalUri, {
      dbName: 'puzzles_assessment_dev',
      serverSelectionTimeoutMS: 8000,
      autoIndex: true,
    });

    console.log(`[Database] Successfully connected to dedicated database: ${mongoose.connection.name}`);

    // Verify and seed default collections and documents in puzzles_assessment_dev
    await initializeAndSeedDatabase();

    return { uri: maskedUri, isConnected: true, dbName: mongoose.connection.name };
  } catch (err: any) {
    console.error(`[Database] Error connecting to MongoDB:`, err.message);
    throw err;
  }
}

export async function initializeAndSeedDatabase() {
  const db = mongoose.connection.db;
  if (!db) {
    console.warn('[Database] Mongoose database object not available for seeding');
    return;
  }

  console.log('[Database] Verifying collections and documents in puzzles_assessment_dev...');

  // 1. Seed Super Admin
  const existingSuperAdmin = await UserModel.findOne({ role: 'super_admin' });
  if (!existingSuperAdmin) {
    const salt = bcrypt.genSaltSync(10);
    await UserModel.create({
      username: 'Rolecall',
      role: 'super_admin',
      passwordHash: bcrypt.hashSync('Roll_Call', salt),
      mustChangePassword: true,
    });
    console.log('[Database] Seeded initial Super Admin (Rolecall)');
  }

  // 2. Seed Schools
  const schoolCount = await SchoolModel.countDocuments();
  let defaultSchoolId = '';
  if (schoolCount === 0) {
    const s1 = await SchoolModel.create({
      name: 'Greenwood High International School',
      code: 'GWH-001',
    });
    const s2 = await SchoolModel.create({
      name: 'Oakridge World Academy',
      code: 'OWA-002',
    });
    defaultSchoolId = s1._id.toString();

    // Seed School Admin
    const adminIdGreenwood = 'ADM-GWH-789';
    const salt = bcrypt.genSaltSync(10);
    await UserModel.create({
      username: adminIdGreenwood,
      role: 'school_admin',
      passwordHash: bcrypt.hashSync(adminIdGreenwood, salt),
      mustChangePassword: true,
      schoolId: defaultSchoolId,
      schoolName: s1.name,
    });

    // Seed Students
    const student1Id = 'STU-701-ALEX';
    await UserModel.create({
      username: student1Id,
      role: 'student',
      passwordHash: bcrypt.hashSync(student1Id, salt),
      mustChangePassword: true,
      schoolId: defaultSchoolId,
      schoolName: s1.name,
      studentName: 'Alex Rivera',
      className: 'Class 7',
      section: 'A',
      schoolAdmissionNumber: 'ADM-2026-701',
      uniqueStudentId: student1Id,
    });

    const student2Id = 'STU-702-PRIYA';
    await UserModel.create({
      username: student2Id,
      role: 'student',
      passwordHash: bcrypt.hashSync(student2Id, salt),
      mustChangePassword: true,
      schoolId: defaultSchoolId,
      schoolName: s1.name,
      studentName: 'Priya Sharma',
      className: 'Class 7',
      section: 'B',
      schoolAdmissionNumber: 'ADM-2026-702',
      uniqueStudentId: student2Id,
    });
    console.log('[Database] Seeded initial schools, school admin, and students');
  }

  // 3. Seed Question Groups
  const groupCount = await QuestionGroupModel.countDocuments();
  if (groupCount === 0) {
    const g1 = await QuestionGroupModel.create({
      name: 'Aptitude',
      description: 'Mathematical, logical reasoning & analytical aptitude',
    });
    const g2 = await QuestionGroupModel.create({
      name: 'Reasoning',
      description: 'Pattern matching, emoji deciphering & deduction',
    });
    const g3 = await QuestionGroupModel.create({
      name: 'Creativity',
      description: 'Spatial reasoning, match combinations & divergent problem solving',
    });
    const g4 = await QuestionGroupModel.create({
      name: 'Thinking',
      description: 'Critical thinking, algebraic logic & multi-step word puzzles',
    });

    // 4. Seed the 5 dummy questions
    try {
      const dummyPath = path.resolve(process.cwd(), 'seed/dummy_questions.json');
      if (fs.existsSync(dummyPath)) {
        const dummyList = JSON.parse(fs.readFileSync(dummyPath, 'utf-8'));
        const groupMap: Record<string, any> = {
          Aptitude: g1,
          Reasoning: g2,
          Creativity: g3,
          Thinking: g4,
        };

        for (const item of dummyList) {
          const matchedGroup = groupMap[item.group] || g1;
          await QuestionModel.create({
            groupId: matchedGroup._id.toString(),
            groupName: item.group,
            difficulty: item.difficulty,
            questionType: item.questionType,
            content: item.content,
            timeSeconds: item.timeSeconds,
            points: item.points,
            options: item.options || [],
            correctAnswer: item.correctAnswer,
            metadata: item.metadata || {},
          });
        }
        console.log('[Database] Seeded 5 development dummy questions into MongoDB collections');
      }
    } catch (e: any) {
      console.warn('[Database] Dummy questions seeding notice:', e.message);
    }
  }

  // Ensure collections exist even if empty so MongoDB Compass displays all collections
  const existingCollections = (await db.listCollections().toArray()).map((c) => c.name);
  const requiredCollections = [
    'users',
    'schools',
    'questiongroups',
    'questions',
    'publishedtests',
    'studenttestassignments',
    'publishhistories',
  ];

  for (const coll of requiredCollections) {
    if (!existingCollections.includes(coll)) {
      try {
        await db.createCollection(coll);
        console.log(`[Database] Created empty collection '${coll}' in puzzles_assessment_dev`);
      } catch (err: any) {
        // collection already exists
      }
    }
  }

  console.log('[Database] puzzles_assessment_dev collections verified successfully.');
}

export function getMongoConnectionInfo() {
  const uri = process.env.MONGO_URI || process.env.MONGODB_URI || '';
  const maskedUri = uri ? uri.replace(/:([^@/]+)@/, ':****@') : 'Not Configured';

  return {
    isConnected: mongoose.connection.readyState === 1,
    readyState: mongoose.connection.readyState,
    host: mongoose.connection.host || 'unknown',
    port: mongoose.connection.port || 0,
    dbName: mongoose.connection.name || 'puzzles_assessment_dev',
    uri: maskedUri,
  };
}

export async function closeMongoDB(): Promise<void> {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }
}
