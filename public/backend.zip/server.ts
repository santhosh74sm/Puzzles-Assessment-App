import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import routes from './backend/routes.ts';
import { connectMongoDB, getMongoConnectionInfo } from './backend/database.ts';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Enable CORS for Flutter mobile/web apps
  app.use(cors({ origin: '*' }));
  app.use(express.json());

  // Establish and verify MongoDB Atlas Connection exclusively to puzzles_assessment_dev
  console.log('[System] Initializing MongoDB database connection...');
  try {
    const dbInfo = await connectMongoDB();
    console.log(`[System] Verified MongoDB connection to: ${dbInfo.dbName} (${dbInfo.uri})`);
  } catch (err: any) {
    console.warn(`[System] MongoDB connection error:`, err.message);
  }

  // Database status and verification endpoint
  app.get('/api/database/status', (req, res) => {
    const info = getMongoConnectionInfo();
    res.json({
      status: info.isConnected ? 'connected' : 'disconnected',
      readyState: info.readyState,
      dbName: info.dbName,
      host: info.host,
      port: info.port,
      uri: info.uri,
    });
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    const info = getMongoConnectionInfo();
    res.json({
      status: 'ok',
      service: 'Puzzles Assessment Engine (Node.js + Express)',
      database: {
        type: 'MongoDB Atlas',
        connected: info.isConnected,
        dbName: info.dbName,
        uri: info.uri,
      },
    });
  });

  // Mount API endpoints
  app.use('/api', routes);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`===================================================`);
    console.log(`  Puzzles Backend running on port ${PORT}`);
    console.log(`  Local URL:        http://localhost:${PORT}/api/health`);
    console.log(`  Android Emulator: http://10.0.2.2:${PORT}/api/health`);
    console.log(`  Target Database:  puzzles_assessment_dev (MongoDB Atlas)`);
    console.log(`===================================================`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
